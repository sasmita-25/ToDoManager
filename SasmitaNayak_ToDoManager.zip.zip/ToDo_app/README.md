# To-Do List Manager

## Features
- ✅ Add/delete tasks
- ✅ Mark tasks as completed
- ⏳ Automatic overdue detection
- 🔍 Filter by status
- 📅 Date validation

## How to Run
```bash
python main.py
```

## File Structure
```
todo-app/
├── main.py
├── tasks.json (auto-created)
└── README.md
```

## Sample Task Entry
```json
{
  "id": 1,
  "title": "Buy groceries",
  "description": "Milk, eggs, bread",
  "due_date": "2023-12-15",
  "priority": "Medium",
  "status": "Pending",
  "created_at": "2023-12-01 14:30:00",
  "completed_at": null
}
```

## Requirements
- Python 3.x
- No external libraries
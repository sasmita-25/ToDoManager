import json
import os
from datetime import datetime

# Configuration
TASKS_FILE = 'tasks.json'
DATE_FORMAT = "%Y-%m-%d"

def initialize_file():
    """Create tasks.json if it doesn't exist"""
    if not os.path.exists(TASKS_FILE):
        with open(TASKS_FILE, 'w') as f:
            json.dump([], f)

def load_tasks():
    """Load tasks with automatic overdue detection"""
    try:
        with open(TASKS_FILE, 'r') as f:
            tasks = json.load(f)
            
            # Update overdue statuses
            for task in tasks:
                if (task['status'] == 'Pending' and 
                    datetime.strptime(task['due_date'], DATE_FORMAT).date() < datetime.now().date()):
                    task['status'] = 'Overdue'
            return tasks
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_tasks(tasks):
    """Save tasks with error handling"""
    try:
        with open(TASKS_FILE, 'w') as f:
            json.dump(tasks, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving tasks: {e}")
        return False

def add_task():
    """Add a new task with validation"""
    tasks = load_tasks()
    
    print("\nAdd New Task")
    while True:
        title = input("Title: ").strip()
        if title: break
        print("Title cannot be empty!")
    
    description = input("Description: ").strip()
    
    while True:
        due_date = input("Due Date (YYYY-MM-DD): ").strip()
        try:
            datetime.strptime(due_date, DATE_FORMAT)
            break
        except ValueError:
            print("Invalid date format. Use YYYY-MM-DD")
    
    priority = input("Priority (High/Medium/Low): ").strip().capitalize()
    while priority not in ['High', 'Medium', 'Low']:
        print("Invalid priority. Choose High/Medium/Low")
        priority = input("Priority: ").strip().capitalize()
    
    new_id = max([task['id'] for task in tasks], default=0) + 1
    
    new_task = {
        'id': new_id,
        'title': title,
        'description': description,
        'due_date': due_date,
        'priority': priority,
        'status': 'Pending',
        'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'completed_at': None
    }
    
    tasks.append(new_task)
    if save_tasks(tasks):
        print(f"\nTask #{new_id} added successfully!")

def view_tasks(tasks=None, filter_type=None):
    """Display tasks with sorting"""
    tasks = tasks or load_tasks()
    
    # Apply filters
    if filter_type == 'pending':
        tasks = [t for t in tasks if t['status'] == 'Pending']
    elif filter_type == 'completed':
        tasks = [t for t in tasks if t['status'] == 'Completed']
    elif filter_type == 'overdue':
        tasks = [t for t in tasks if t['status'] == 'Overdue']
    
    # Sort by priority then due date
    priority_order = {'High': 1, 'Medium': 2, 'Low': 3}
    tasks.sort(key=lambda x: (priority_order[x['priority']], x['due_date']))
    
    print("\n--- TASKS ---")
    for task in tasks:
        status_color = ""
        if task['status'] == 'Completed':
            status_color = "\033[92m"  # Green
        elif task['status'] == 'Overdue':
            status_color = "\033[91m"  # Red
        
        print(f"\nID: {task['id']}")
        print(f"Title: {task['title']}")
        print(f"Due: {task['due_date']}")
        print(f"Priority: {task['priority']}")
        print(f"Status: {status_color}{task['status']}\033[0m")
        if task['description']:
            print(f"Description: {task['description']}")

def mark_completed():
    """Mark task as completed"""
    tasks = load_tasks()
    view_tasks(tasks, 'pending')
    
    try:
        task_id = int(input("\nEnter task ID to complete (0 to cancel): "))
        if task_id == 0: return
        
        for task in tasks:
            if task['id'] == task_id:
                task['status'] = 'Completed'
                task['completed_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if save_tasks(tasks):
                    print(f"Task #{task_id} marked as completed!")
                return
        
        print(f"Task #{task_id} not found!")
    except ValueError:
        print("Invalid input. Enter a number.")

def delete_task():
    """Delete a task by ID"""
    tasks = load_tasks()
    view_tasks(tasks)
    
    try:
        task_id = int(input("\nEnter task ID to delete (0 to cancel): "))
        if task_id == 0: return
        
        tasks = [t for t in tasks if t['id'] != task_id]
        if save_tasks(tasks):
            print(f"Task #{task_id} deleted!")
        else:
            print("Error saving changes")
    except ValueError:
        print("Invalid input. Enter a number.")

def main():
    initialize_file()  # Ensure file exists
    
    while True:
        print("\n=== TO-DO LIST MANAGER ===")
        print("1. Add Task")
        print("2. View All Tasks")
        print("3. View Pending Tasks")
        print("4. View Completed Tasks")
        print("5. View Overdue Tasks")
        print("6. Mark Task as Completed")
        print("7. Delete Task")
        print("8. Exit")
        
        choice = input("\nEnter choice (1-8): ")
        
        if choice == '1':
            add_task()
        elif choice == '2':
            view_tasks()
        elif choice == '3':
            view_tasks(filter_type='pending')
        elif choice == '4':
            view_tasks(filter_type='completed')
        elif choice == '5':
            view_tasks(filter_type='overdue')
        elif choice == '6':
            mark_completed()
        elif choice == '7':
            delete_task()
        elif choice == '8':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Enter 1-8.")

if __name__ == "__main__":
    main()